
<?php


class CPLCategories
{
    public $table_role = 'capabilities_role';
    public $table_user = 'capabilities_user';
    public function cc_get_roles()
    {
        global $wp_roles;
        $roles = $wp_roles->roles;
        return $roles;
    }

    public function cc_get_users()
    {
        return get_users();
    }

    public function cc_get_categories()
    {
        return get_categories();
    }

    function cc_create_db()
    {
        // $this->cc_create_table_roles();
        $this->cc_create_table_user();
    }

    private function cc_create_table_user()
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table_user;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table(
          id mediumint(9) NOT NULL AUTO_INCREMENT,
          username text NOT NULL,
          categories text NOT NULL,
          PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    private function cc_create_table_roles()
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table_role;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table(
          id mediumint(9) NOT NULL AUTO_INCREMENT,
          roles text NOT NULL,
          categories text NOT NULL,
          PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    function cc_insert_categories_for_user($user, $categories_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table_user;
        $get_users = $this->cc_get_categories_for_user($user);
        $parents = $this->cc_get_parent_of_category_id($categories_id);

        // $term_ids = array_merge($categories_id,$parent);
        foreach($parents as $par){
            if($par->parent != 0){
                array_push($categories_id,$par->parent);
            }
        }
        $categories_data = $this->cc_deserialize($categories_id);
        if (isset($get_users)) {
            $wpdb->update($table, array('categories' => $categories_data), array('username' => $user));
        } else {
            $wpdb->insert(
                $table,
                array(
                    'username' => $user,
                    'categories' => $categories_data,
                )
            );
        }
    }

    function cc_clear($user){
        global $wpdb;
        $table = $wpdb->prefix . $this->table_user;
        $get_users = $this->cc_get_categories_for_user($user);
            $wpdb->delete(
                $table,
                array(
                    'username' => $user,
                )
            );
        }

    function cc_get_parent_of_category_id($categories_id){
        global $wpdb;
        $categories_data =  implode(",", $categories_id);
        $query = 'SELECT parent FROM wp_term_taxonomy WHERE term_id IN ('. $categories_data.') GROUP BY parent';
        $result = $wpdb->get_results($query);
        return $result;
    }


    function cc_insert_categories_for_roles($role, $categories_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table_role;
        $categories_data = $this->cc_deserialize($categories_id);
        $get_roles = $this->cc_get_categories_for_role($role);
        if (isset($get_roles)) {
            $wpdb->update($table, array('categories' => $categories_data), array('roles' => $role));
        } else {
            $wpdb->insert(
                $table,
                array(
                    'roles' => $role,
                    'categories' => $categories_data,
                )
            );
        }
    }

    function cc_get_categories_for_user($user)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table_user;
        $query = 'SELECT * FROM ' . $table . ' WHERE username = \'' . $user . '\'';
        $result = $wpdb->get_results($query);
        if (isset($result)) {
            if (isset($result[0])) {
                $categories = $this->cc_serialize($result[0]->categories);
                $data = array();
                $data[$user] = $categories;
                return $data;
            }
            return null;
        }
        return null;
    }


    function cc_get_categories_for_role($role)
    {
        global $wpdb;
        $table = $wpdb->prefix . $this->table_role;
        $query = 'SELECT * FROM ' . $table . ' WHERE roles = \'' . $role . '\'';
        $result = $wpdb->get_results($query);
        if (isset($result)) {
            if (isset($result[0])) {
                $categories = $this->cc_serialize($result[0]->categories);
                $data = array();
                $data[$role] = $categories;
                return $data;
            }
            return null;
        }
        return null;
    }

    // Chuyển mảng thành chuỗi với khoảng trắng ở giữa
    function cc_deserialize($categories_id)
    {
        return implode(" ", $categories_id);
    }

    // Chuyển chuỗi thành mảng
    function cc_serialize($data)
    {
        return explode(" ", $data);
    }

    function cc_get_category_by_ID($id)
    {
        return get_the_category_by_ID($id);
    }

    function cc_get_current_user()
    {
        return wp_get_current_user();
    }

    function cc_get_term_id()
    {
        global $wpdb;
        $query = 'SELECT term_id  FROM  wp_terms';
        $result = $wpdb->get_results($query);
        if (isset($result)) {
            return $result;
        }
        return null;
    }
}
