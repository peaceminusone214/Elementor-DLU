<?php

/**
 * Plugin Name: Phân quyền người dùng CICT - DLU
 * Plugin URI: http://codepsoft.com
 * Description: Allow user to decentralize by category
 * Version: 1.0.1
 * Author: Phan Trung Tinh
 * Author URI: http://codepsoft.com
 * License: GPLv2 or later
 */

/**
 * Set the wp-content and plugin urls/paths
 */
if (!defined('WP_CONTENT_URL'))
  define('WP_CONTENT_URL', get_option('siteurl') . '/wp-content');
if (!defined('WP_CONTENT_DIR'))
  define('WP_CONTENT_DIR', ABSPATH . 'wp-content');
if (!defined('WP_PLUGIN_URL'))
  define('WP_PLUGIN_URL', WP_CONTENT_URL . '/plugins');
if (!defined('WP_PLUGIN_DIR'))
  define('WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins');


require 'define-class/capabilities-categories.php';

register_uninstall_hook(__FILE__, 'cplc_delete_plugin');

function cplc_delete_plugin()
{
  global $wpdb;
  $drop_table_user = 'DROP TABLE IF EXIST wp_capabilities_user';
  $drop_table_role = 'DROP TABLE IF EXIST wp_capabilities_role';
  $wpdb->query($drop_table_user);
  $wpdb->query($drop_table_role);
}

add_action('admin_menu', 'cplc_menu');

function cplc_admin_style()
{
  wp_enqueue_style('style', plugins_url('/css/style.css', __FILE__));
}
add_action('admin_enqueue_scripts', 'cplc_admin_style');

$GLOBALS['cc'] = new CPLCategories();

function cplc_menu()
{
  $page_title = 'Phân quyền người dùng';
  $menu_title = 'Phân quyền người dùng';
  $capability = 'manage_options';
  $menu_slug  = 'capabilities-catetogies';
  $function   = 'cplc_admin_tabs';
  $icon_url   = 'dashicons-media-code';
  $position   = 8;
  add_menu_page($page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position);
  $cc = $GLOBALS['cc'];
  $cc->cc_create_db();
}


function cplc_admin_tabs($current = 'users')
{
  //tabs with tab ROLES
  // $tabs = array('roles' => 'Roles', 'users' => 'Users', 'about' => 'About');
  //tab without tab ROLES
  // $tabs = array('users' => 'Users', 'about' => 'About');
  // echo '<div id="icon-themes" class="icon32"><br></div>';
  // echo '<h2 class="nav-tab-wrapper">';
  // foreach ($tabs as $tab => $name) {
  //   $class = ($tab == $current) ? ' nav-tab-active' : '';
  //   echo "<a class='nav-tab$class' href='?page=capabilities-catetogies&tab=$tab'>$name</a>";
  // }
  // echo '</h2>';
  // if (isset($_GET['tab'])) {
  //   $tab_name = $_GET['tab'];
  //   $current = $tab_name;
  //   switch ($tab_name) {
  //     case 'roles':
  //       cplc_roles_tab();
  //       break;
  //     case 'users':
  //       cplc_users_tab();
  //       break;
  //     case 'about':
  //       cplc_about_tab();
  //       break;
  //     default:
  //       cplc_users_tab();
  //       break;
  //   }
  // }
  cplc_users_tab();
}



function cplc_roles_tab()
{
  echo '<h1> Role tab  </h1>';
  cplc_create_role_tab_data();
}

function cplc_users_tab()
{
  echo '<h2>Phân quyền cho các tài khoảng người dùng theo chuyên mục</h2>';
  cplc_create_user_tab_data();
}

function cplc_about_tab()
{
  echo '<h1> About Capabilities Categories for Users  </h1>';
  echo '<hp Website: <a href= http://codepsoft.com > codepsoft.com </a></p>';
  echo '<p>  Decription:Allow user to decentralize by category   <p>';
  echo '<p>  Author: Phan Trung Tinh </p>';
}

function cplc_create_role_tab_data()
{
  $cc = $cc = $GLOBALS['cc'];
  $roles = $cc->cc_get_roles();
  $categories = $cc->cc_get_categories();
  $data = array();
  foreach ($roles as $role) {
    $data[$role['name']] = $categories;
  }
  cplc_display_form($data, 'roles');
}

function cplc_create_user_tab_data()
{
  $cc = $GLOBALS['cc'];
  $categories = $cc->cc_get_categories();
  $users = $cc->cc_get_users();
  $data = array();
  foreach ($users as $user) {
    $data[$user->user_nicename] = $categories;
  }

  cplc_display_form($data, 'user');
}

function cplc_display_form($data, $tab)
{

  if (isset($_POST['result'])) {
    $checked =  $_POST['result'];
    if ($tab == 'roles') {
      cplc_insert_role_categories_to_db($checked);
    } else {
      cplc_insert_user_categories_to_db($checked);
    }
  }
  $cc = $GLOBALS['cc'];

  echo '<div class="cc-wrap">';
  echo '<form action="" method="post" class="form-main">';
  $i = 0;
  foreach ($data as $key => $categories) {
    $i++;
    echo '<div class="container s' . $i . '">';
    echo '<h3>' . esc_html($key) . '</h3>';
    echo '<div class="box">';
    $name_key = 'result[' . $key . '][]';
    if ($tab == 'roles') {
      $categories_checked = $cc->cc_get_categories_for_role($key);
    } else {
      $categories_checked = $cc->cc_get_categories_for_user($key);
    }
    foreach ($categories as $ce) {
      $term_id = $ce->term_id;
      $checked = "";
      if (isset($categories_checked)) {
        $isCheck = in_array(strval($term_id), $categories_checked[$key]);
        if ($isCheck) {
          $checked = "checked";
        }
      }
      echo '<input type="checkbox" class="category" name="' . $name_key . '" value="' . $term_id . '" ' . $checked . '>' . '   ' . esc_html($ce->name) . '</input>';
      echo '<br>';
    }
    echo '<div style="float: right;">';
    echo '<button type="button" class="button btnXoa s' . $i . '" style="margin: 5px;">Bỏ chọn tất cả</button>';
    echo '<input type="checkbox" class="chk_boxes s' . $i . '" style="margin-top: 11px; margin-left: 11px; margin-bottom: 11px;">Chọn tất cả</input>';
    echo '</div>';
    echo '</div>';
?>
    <script type="text/javascript">
      (function($) {
        $('.chk_boxes.s<?php echo $i ?>').click(function() {
          $('.container.s<?php echo $i ?> input[type="checkbox"]').prop('checked', this.checked)
        })
      })(jQuery);
      (function($) {
        $('.btnXoa.s<?php echo $i ?>').click(function() {
          $('.container.s<?php echo $i ?> input[type="checkbox"]').removeAttr("checked")
        })
      })(jQuery);
    </script>
<?php
    echo '</div>';
  }
  echo '<div class="break">';
  echo '<input type="submit" name="save-changed" value="Lưu thay đổi" class="button"/>';
  echo '</div>';
  echo '</form>';
  echo '</div>';
}


function cplc_insert_user_categories_to_db($result)
{
  $cc = $GLOBALS['cc'];
  $users = $cc->cc_get_users();
  $data = array();
  foreach ($users as $user) {
    array_push($data, $user->user_nicename);
  }

  if (isset($result)) {
    foreach ($result as $key => $categories) {
      if (($index = array_search($key, $data)) !== false) {
        unset($data[$index]);
      }
      $cc->cc_insert_categories_for_user($key, $categories);
    }
    foreach ($data as $key) {
      $cc->cc_clear($key);
    }
  }
}

function cplc_insert_role_categories_to_db($result)
{
  $cc = $GLOBALS['cc'];
  if (isset($result)) {
    foreach ($result as $key => $categories) {
      $cc->cc_insert_categories_for_roles($key, $categories);
    }
  }
}

function ezfm_get_current_post_type()
{

  global $post, $typenow, $current_screen;

  if ($post && $post->post_type) return $post->post_type;

  elseif ($typenow) return $typenow;

  elseif ($current_screen && $current_screen->post_type) return $current_screen->post_type;

  elseif (isset($_REQUEST['post_type'])) return sanitize_key($_REQUEST['post_type']);

  return null;
}

function cplc_filler_pre_post($query)
{
  if (current_user_can('administrator')) {
    return;
  }
  global $pagenow;
  if (($pagenow == 'edit.php') && (ezfm_get_current_post_type() == 'post')) {
    $cc = new CPLCategories();
    $current_user = $cc->cc_get_current_user();
    $user_name = $current_user->user_nicename;
    $categories_from_db = $cc->cc_get_categories_for_user($user_name);
    if (isset($categories_from_db[$user_name])) {
      $query->set('author', $current_user->ID);
      $query->set('category__in', $categories_from_db[$user_name]);
    }
  }


  return $query;
}

if (is_admin()) {
  add_filter('pre_get_posts', 'cplc_filler_pre_post');
}

function is_edit_page($new_edit = null)
{
  global $pagenow;
  //make sure we are on the backend
  // if (!is_admin()) return false;


  if ($new_edit == "edit")
    return in_array($pagenow, array('post.php',));
  elseif ($new_edit == "new") //check for new post page
    return in_array($pagenow, array('post-new.php'));
  else //check for either new or edit
    return in_array($pagenow, array('post.php', 'post-new.php'));
}


function cplc_hide_categories_for_specific_user($exclusions, $args)
{


  if (current_user_can('administrator')) {
    return;
  }

  $cc = new CPLCategories();
  $current_user = $cc->cc_get_current_user();
  $user_name = $current_user->user_nicename;
  $categories_from_db = $cc->cc_get_categories_for_user($user_name);
  $terms = $cc->cc_get_term_id();
  $ids = array();

  foreach ($terms as $object) {
    array_push($ids, $object->term_id);
  }
  if (isset($categories_from_db[$user_name]) && isset($ids)) {
    $temp = array_diff($ids, $categories_from_db[$user_name]);
    $exclude_array = array_diff($temp, [1]);
  } else {
    $exclude_array = array();
  }
  // $exclude_array = array(3,6,7,8,9,10,11,12,13,14,15,29,30,31,32);

  // Generation of exclusion SQL code
  $exterms = wp_parse_id_list($exclude_array);
  foreach ($exterms as $exterm) {
    if (empty($exclusions))
      $exclusions = ' AND ( t.term_id <> ' . intval($exterm) . ' ';
    else
      $exclusions .= ' AND t.term_id <> ' . intval($exterm) . ' ';
  }
  // Closing bracket
  if (!empty($exclusions))
    $exclusions .= ')';
  return $exclusions;
}

if (!is_admin()) {
  add_filter('list_terms_exclusions', 'cplc_hide_categories_for_specific_user', 10, 2);
}


add_filter('quick_edit_show_taxonomy', function ($show, $taxonomy_name, $view) {

  if ('category' == $taxonomy_name)
    return false;

  return $show;
}, 10, 3);

// add_action( 'load-edit.php', 'no_category_dropdown' );
// function no_category_dropdown() {
//     add_filter( 'wp_dropdown_cats', '__return_false' );
// }

// 
add_action('restrict_manage_posts', 'restrict_fillter_category_capabilities', 10, 1);
function restrict_fillter_category_capabilities($post_type)
{
  $args = array();
  if ($post_type == 'post') {
    $cc = new CPLCategories();
    $current_user = $cc->cc_get_current_user();
    $user_name = $current_user->user_nicename;
    $categories_from_db = $cc->cc_get_categories_for_user($user_name);
    $terms = $cc->cc_get_term_id();
    $ids = array();

    foreach ($terms as $object) {
      array_push($ids, $object->term_id);
    }
    if (isset($categories_from_db[$user_name]) && isset($ids)) {
      $temp = array_diff($ids, $categories_from_db[$user_name]);
      $exclude_array = array_diff($temp, [1]);
    } else {
      $exclude_array = array();
    }
    // $exclude_array = array(3,6,7,8,9,10,11,12,13,14,15,29,30,31,32);

    // Generation of exclusion SQL code
    $exterms = wp_parse_id_list($exclude_array);
    $args = array(
      'show_option_all' =>  __("Show All"),
      'orderby'         =>  'name',
      // 'selected'        =>  $wp_query->query['term'],
      'hierarchical'    =>  true,
      'show_option_none'=>false,
      'depth'           =>  3,
      'hide_empty'      =>  true, // Don't show businesses w/o listings
      'exclude' => $exterms,
    );
    wp_dropdown_categories($args);
  }
  
}


